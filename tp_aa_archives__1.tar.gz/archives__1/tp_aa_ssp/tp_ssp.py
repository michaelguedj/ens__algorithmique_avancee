'''
    TP - SOMME DU SOUS-ENSEMBLE - SSP
'''

import math
import random
randint = random.randint
log = math.log

# k tests au hasard
# selection de la meilleur solution
def hasard(lst, k):
    #prendre indice tant que l'on peut
    res = []
    indice = [i for i in range(len(lst))]
    # ...
    return

def glouton(lst, c):
    n = len(lst)
    res = []
    sum_res = 0
    lst.sort()
    lst.reverse()
    for i in range(n):
        if lst[i] + sum_res <= c:
            res.append(lst[i])
            sum_res += lst[i]
    return res, sum_res

if __name__ == '__main__':
    for n in [2**4, 2**5, 2**6, 2**7, 2**10]:
        MAX = n**2
        c = int(MAX*log(MAX)) 
        lst = [randint(1, n**2) for i in range(n)]
        # print(lst)
        print('c=', c)
        res, sum_res = glouton(lst, c)
        print('approximation :', 100*sum_res/c, '%')
